package mnll;


public class DBAppException extends Exception  {
	
	public DBAppException(String m){
		super(m);
	}
}