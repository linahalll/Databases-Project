package mnll;

import java.awt.Dimension;
import java.awt.Polygon;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;
import java.util.Vector;
import java.io.*;

public class DBApp implements java.io.Serializable {
	
	private int n;
	
	public DBApp() {
		Properties prop = new Properties();
		try {
			prop.load(new FileInputStream("config/DBApp.properties"));
			n = Integer.parseInt(prop.getProperty("MaximumRowsCountinPage"));
			File f = new File("data");
			File[] files = f.listFiles();
			for (File file : files) { file.delete(); }
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void init() {
		Properties prop = new Properties();
		try {
			prop.load(new FileInputStream("config/DBApp.properties"));
			n = Integer.parseInt(prop.getProperty("MaximumRowsCountinPage"));
			File f = new File("data");
			File[] files = f.listFiles();
			for (File file : files) { file.delete(); }
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

	public String getType(String tableName, String columnName) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(new File("data/metadata.csv")));
		String line = "";
		String type = "";
		while ((line = br.readLine()) != null) {
			String[] records = line.split(", ");
			if(records[0].equals(tableName) && records[1].equals(columnName)) {
				type = records[2];
				break;
			}
		}
		br.close();
		return type;
	}

	public String getKey(String tableName) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("data/metadata.csv"));
		String line = "";
		String key = "";
		while ((line = br.readLine()) != null) {
			String[] records = line.split(", ");
			if(records[0].equals(tableName) && records[3].equals("true")) {
				key = records[1];
				break;
			}
		}
		br.close();
		return key;
	}

	public void serialize(String fileName, Vector<Hashtable<String, Object>> vector) {
		try {
	         FileOutputStream fileOut = new FileOutputStream(fileName);
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
	         out.writeObject(vector);
	         out.close();
	         fileOut.close();
	    } catch (IOException e) {
	    	System.out.println(e.getMessage());
	    }
	}

	public Vector<Hashtable<String, Object>> deserialize(String fileName) {
		Vector<Hashtable<String, Object>> vector = new Vector<Hashtable<String, Object>>();
		try {
			FileInputStream fileIn = new FileInputStream(fileName);
			ObjectInputStream in = new ObjectInputStream(fileIn);
			vector = (Vector<Hashtable<String, Object>>)in.readObject();
			in.close();
			fileIn.close();
		} catch (IOException | ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		return vector;
	}

	public Boolean isSmaller(Object o1, Object o2, String type) {
		switch(type) {
		case "java.lang.Integer": return (int)o1 > (int)o2;
		case "java.lang.String": return ((String)o1).compareTo((String)o2) < 0;
		case "java.lang.Double": return (Double)o1 > (Double)o2;
		case "java.lang.Boolean": if ((Boolean)o1 && !((Boolean)o2)) { return true; } return false; 
		case "java.util.Date": return ((Date)o1).compareTo((Date)o2) < 0;
		case "java.awt.Polygon":
			Dimension d1= ((Polygon)o1).getBounds().getSize();
			Dimension d2= ((Polygon)o1).getBounds().getSize();
			int a1 = d1.width * d1.height;
			int a2 = d2.width*d2.height;
			return a1 > a2;
		default: break;
		}
		return false;
	}
	
	public Boolean isEqual(Object o1, Object o2, String type) {
		switch(type) {
		case "java.lang.Integer": return (int)o1 == (int)o2;
		case "java.lang.String": return ((String)o1).equals((String)o2);
		case "java.lang.Double": return (Double)o1 == (Double)o2;
		case "java.lang.Boolean": return (Boolean)o1 == (Boolean)o2; 
		case "java.util.Date": return ((Date)o1).compareTo((Date)o2) == 0;
		case "java.awt.Polygon":
			Dimension d1= ((Polygon)o1).getBounds().getSize();
			Dimension d2= ((Polygon)o1).getBounds().getSize();
			int a1 = d1.width * d1.height;
			int a2 = d2.width*d2.height;
			return a1 == a2;
		default: break;
		}
		return false;
	}
	
	public void createTable(String strTableName, String strClusteringKeyColumn, Hashtable<String, String> htblColNameType) throws DBAppException{
		try {
			FileWriter fw = new FileWriter("data/metadata.csv", true);
			BufferedWriter bw = new BufferedWriter(fw);
			PrintWriter out = new PrintWriter(bw);
			out.println(strTableName+", "+strClusteringKeyColumn+", "+htblColNameType.get(strClusteringKeyColumn)+", true, false");
			htblColNameType.remove(strClusteringKeyColumn);
			for (String key : htblColNameType.keySet()) {
				out.println(strTableName+", "+key+", "+htblColNameType.get(key)+", false, false");
			}
			out.println(strTableName+", TouchDate, java.util.Date, false, false");
			out.close();
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void insertIntoTable(String strTableName, Hashtable<String, Object> htblColNameValue) throws DBAppException {		
		try {
			htblColNameValue.put("TouchDate", new Date());
			BufferedReader br = new BufferedReader(new FileReader("data/metadata.csv"));
			String line = br.readLine();
			int lines = 1;
			while ((line = br.readLine()) != null) {
				String[] records = line.split(", ");
				if(records[0].equals(strTableName)) { lines ++; }
				else { break; }
			}
			br.close();
			if (lines != htblColNameValue.size()) { throw new DBAppException("Missing arg"); }
			for(String key : htblColNameValue.keySet()) {
				switch(getType(strTableName, key)) {
				case "java.lang.Integer": if (!(htblColNameValue.get(key) instanceof Integer)) { throw new DBAppException("Wrong datatype int"); } break;
				case "java.lang.String": if (!(htblColNameValue.get(key) instanceof String)) { throw new DBAppException("Wrong datatype string"); } break;
				case "java.lang.Double": if (!(htblColNameValue.get(key) instanceof Double)) { throw new DBAppException("Wrong datatype double"); } break;
				case "java.lang.Boolean": if (!(htblColNameValue.get(key) instanceof Boolean)) { throw new DBAppException("Wrong datatype boolean"); } break;
				case "java.util.Date": if (!(htblColNameValue.get(key) instanceof Date)) { throw new DBAppException("Wrong datatype date"); } break;
				case "java.awt.Polygon": if (!(htblColNameValue.get(key) instanceof Polygon)) { throw new DBAppException("Wrong datatype polygon"); } break;
				default: throw new DBAppException("Wrong datatype"); 
				}
			}
			int count = 0;
			String fileName = "data/"+strTableName+count+".class";
			Vector<Hashtable<String, Object>> vector = new Vector<Hashtable<String, Object>>();
			if (!((new File(fileName)).exists())) {
				vector.add(htblColNameValue);
				serialize(fileName, vector);
				return;
			}
 			while ((new File(fileName)).exists()) {
				vector = deserialize(fileName);
				Hashtable<String, Object> lastElement = vector.lastElement();
				String key = getKey(strTableName);
				String type = getType(strTableName, key);
				if (isSmaller(lastElement.get(key), htblColNameValue.get(key), type)) {
					if (vector.size() == 1) {
						vector.add(1, htblColNameValue);
						serialize(fileName, vector);
						return;
					}
					int l = 0;
					int r = vector.size()-1; 
			        while (l <= r) { 
			            int m = l + (r - l) / 2;
			            if (isSmaller(htblColNameValue.get(key), vector.get(m).get(key), type)) {
			            	if (m+1 < vector.size()-1 && !(isSmaller(htblColNameValue.get(key), vector.get(m+1).get(key), type))) {
			            		vector.add(m+1, htblColNameValue);
				            	if (vector.size() > n) {
				            		vector.remove(lastElement);
				            		serialize(fileName, vector);
				            		insertIntoTable(strTableName, lastElement);
				            	} else {
									serialize(fileName, vector);
				            	}
				            	return;
			            	}
			            } else if (isSmaller(htblColNameValue.get(key), vector.get(m).get(key), type)) l = m + 1; 
			 		    else r = m - 1; 
			        }
				} else if ((new File("data/"+strTableName+(count+1)+".class").exists())){
					Hashtable<String, Object> firstElement = deserialize("data/"+strTableName+(count+1)+".class").firstElement();
					if (isSmaller(firstElement.get(key), htblColNameValue.get(key), type)) {
						vector.add(vector.size(), htblColNameValue);
						if (vector.size() > n) {
		            		vector.remove(lastElement);
		            		serialize(fileName, vector);
		            		insertIntoTable(strTableName, lastElement);
		            	} else {
							serialize(fileName, vector);
		            	}
						return;
					}
				} else if (vector.size() < n){
					vector.add(vector.size(), htblColNameValue);
					serialize(fileName, vector);
					return;
				} else {
					vector.clear();
					vector.add(htblColNameValue);
					serialize("data/"+strTableName+(count+1)+".class", vector);
					return;
				}
				count ++;
				fileName = "data/"+strTableName+count+".class";
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

	public void updateTable(String strTableName, String strClusteringKey, Hashtable<String, Object> htblColNameValue) throws DBAppException {
		
		htblColNameValue.put("TouchDate", new Date());
		try {
			for(String key : htblColNameValue.keySet()) {
				switch(getType(strTableName, key)) {
				case "java.lang.Integer": if (!(htblColNameValue.get(key) instanceof Integer)) { throw new DBAppException("Wrong datatype"); } break;
				case "java.lang.String": if (!(htblColNameValue.get(key) instanceof String)) { throw new DBAppException("Wrong datatype"); } break;
				case "java.lang.Double": if (!(htblColNameValue.get(key) instanceof Double)) { throw new DBAppException("Wrong datatype"); } break;
				case "java.lang.Boolean": if (!(htblColNameValue.get(key) instanceof Boolean)) { throw new DBAppException("Wrong datatype"); } break;
				case "java.util.Date": if (!(htblColNameValue.get(key) instanceof Date)) { throw new DBAppException("Wrong datatype"); } break;
				case "java.awt.Polygon": if (!(htblColNameValue.get(key) instanceof Polygon)) { throw new DBAppException("Wrong datatype"); } break;
				default: break;
				}
			}
			
			int count = 0;
			String fileName = "data/"+strTableName+count+".class";
			Vector<Hashtable<String, Object>> vector = new Vector<Hashtable<String, Object>>();
			while ((new File(fileName)).exists()) {
				vector = deserialize(fileName);
				Hashtable<String, Object> lastElement = vector.lastElement();
				String key = getKey(strTableName);
				String type = getType(strTableName, key);
				Object value = null;
				switch(type){
				case "java.lang.Integer": value = Integer.parseInt(strClusteringKey); break;
				case "java.lang.String": value = strClusteringKey; break;
				case "java.lang.Double": value = Double.parseDouble(strClusteringKey); break;
				case "java.lang.Boolean": value = Boolean.valueOf(strClusteringKey); break;
				case "java.util.Date": value = new Date(strClusteringKey); break;
				case "java.awt.Polygon":
					Polygon polygon = new Polygon();
					String[] points = strClusteringKey.split("(");
					for (String p : points) { 
						String[] ps = p.substring(0, p.length()-1).split(",");
						polygon.addPoint(Integer.parseInt(ps[0]), Integer.parseInt(ps[1]));
						value = polygon;
					}
					break;
				default: break;
				}
				if (lastElement.get(key).equals(value)) {
	            	for (String k : htblColNameValue.keySet()){ vector.get(vector.size()-1).put(k, htblColNameValue.get(k)); }
				}
				if (isSmaller(lastElement.get(key), value, type)) {
					int l = 0;
					int r = vector.size()-1; 
			        while (l <= r) { 
			            int m = l + (r - l) / 2; 
			            if (isSmaller(value, vector.get(m).get(key), type) && !(isSmaller(value, vector.get(m+1).get(key), type))) {
			            	for (String k : htblColNameValue.keySet()){ vector.get(m).put(k, htblColNameValue.get(k)); }
			            }
			 		    if (isSmaller(value, vector.get(m).get(key), type)) l = m + 1; 
			 		    else r = m - 1; 
			        }
				}
				serialize(fileName, vector);
				count ++;
				fileName = "data/"+strTableName+count+".class";
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

	public void deleteFromTable(String strTableName, Hashtable<String, Object> htblColNameValue) throws DBAppException {
		try {
			int count = 0;
			String fileName = "data/"+strTableName+count+".class";
			Vector<Hashtable<String, Object>> vector = new Vector<Hashtable<String, Object>>();
			Vector<Hashtable<String, Object>> delete = new Vector<Hashtable<String, Object>>();
			while ((new File(fileName)).exists()) {
				vector = deserialize(fileName);
				for (Hashtable<String, Object> hash : vector) {
					boolean same = true;
					for (String key : htblColNameValue.keySet()) {
						if (!(isEqual(hash.get(key), htblColNameValue.get(key), getType(strTableName, key)))) same = false;
					}
					if (same) delete.add(hash);
				}
				vector.removeAll(delete);
				if (vector.size() == 0) {
					(new File(fileName)).delete();
				} else {
					serialize(fileName, vector);	
				}
				count ++;
				fileName = "data/"+strTableName+count+".class";
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

	public Iterator selectFromTable(SQLTerm[] arrSQLTerms, String[] strarrOperators) throws DBAppException { return null; }
	
	public static void main(String[] args) {
		try {
			String strTableName = "Student";
			DBApp dbApp = new DBApp( );
			Hashtable htblColNameType = new Hashtable( );
			htblColNameType.put("id", "java.lang.Integer");
			htblColNameType.put("name", "java.lang.String");
			htblColNameType.put("gpa", "java.lang.Double");
			dbApp.createTable( strTableName, "id", htblColNameType );
			Hashtable htblColNameValue = new Hashtable( );
			htblColNameValue.put("id", new Integer( 1 ));
			htblColNameValue.put("name", new String("Ahmed Noor" ) );
			htblColNameValue.put("gpa", new Double( 0.95 ) );
			dbApp.insertIntoTable(strTableName , htblColNameValue);
			htblColNameValue.clear( );
			htblColNameValue.put("id", new Integer( 3 ));
			htblColNameValue.put("name", new String("Dalia Noor" ) );
			htblColNameValue.put("gpa", new Double( 1.25 ) );
			dbApp.insertIntoTable( strTableName , htblColNameValue );
			htblColNameValue.clear( );
			htblColNameValue.put("id", new Integer( 4 ));
			htblColNameValue.put("name", new String("John Noor" ) );
			htblColNameValue.put("gpa", new Double( 1.5 ) );
			dbApp.insertIntoTable( strTableName , htblColNameValue );
			htblColNameValue.clear( );
			htblColNameValue.put("id", new Integer( 2 ));
			htblColNameValue.put("name", new String("Zaky Noor" ) );
			htblColNameValue.put("gpa", new Double( 0.88 ) );
			dbApp.insertIntoTable( strTableName , htblColNameValue );
//			htblColNameValue = new Hashtable( );
//			htblColNameValue.put("name", new String("Ahmed Nour" ) );
//			htblColNameValue.put("gpa", new Double( 0.95 ) );
//			dbApp.updateTable(strTableName, "2343432", htblColNameValue);
//			htblColNameValue = new Hashtable( );
//			htblColNameValue.put("name", new String("Ahmed Nour" ) );
//			dbApp.deleteFromTable(strTableName, htblColNameValue);
			int count = 0;
			String fileName = "data/"+strTableName+count+".class";
			Vector<Hashtable<String, Object>> vector = new Vector<Hashtable<String, Object>>();
			while ((new File(fileName)).exists()) {
				vector = dbApp.deserialize("data/"+strTableName+0+".class");
				for (Hashtable<String, Object> hash : vector) {
					System.out.println(hash);
				}
				count += 10;
				fileName = "data/"+strTableName+count+".class";
			}
		} catch (DBAppException e) {
			System.out.println(e.getMessage());
		}
//		dbApp.createBIndex( strTableName, "gpa" );
//		SQLTerm[] arrSQLTerms;
//		arrSQLTerms = new SQLTerm[2];
//		arrSQLTerms[0]._strTableName = "Student";
//		arrSQLTerms[0]._strColumnName= "name";
//		arrSQLTerms[0]._strOperator = "=";
//		arrSQLTerms[0]._objValue = "John Noor";
//		arrSQLTerms[1]._strTableName = "Student";
//		arrSQLTerms[1]._strColumnName= "gpa";
//		arrSQLTerms[1]._strOperator = "=";
//		arrSQLTerms[1]._objValue = new Double( 1.5 );
//		String[]strarrOperators = new String[1];
//		strarrOperators[0] = "OR";
//		// select * from Student where name = �John Noor� or gpa = 1.5;
//		Iterator resultSet = dbApp.selectFromTable(arrSQLTerms , strarrOperators);
	}
}